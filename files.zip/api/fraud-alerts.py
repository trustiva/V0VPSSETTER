import os
import psycopg2
from flask import Flask, jsonify

app = Flask(__name__)
DB_URL = os.getenv("DATABASE_URL")

@app.route("/api/fraud-alerts")
def fraud_alerts():
    conn = psycopg2.connect(DB_URL)
    with conn.cursor() as cur:
        cur.execute("""
            SELECT id, affiliate_id, reason, n_clicks, ts
            FROM affiliate_fraud_alerts
            ORDER BY ts DESC
            LIMIT 100
        """)
        alerts = [
            {"id": row[0], "affiliate_id": row[1], "reason": row[2], "n_clicks": row[3], "ts": row[4].isoformat()}
            for row in cur.fetchall()
        ]
    conn.close()
    return jsonify(alerts)