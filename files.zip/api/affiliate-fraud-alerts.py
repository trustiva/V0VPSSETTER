import os
import psycopg2
from flask import Flask, jsonify

app = Flask(__name__)
DB_URL = os.getenv("DATABASE_URL")

@app.route("/api/affiliate-fraud-alerts")
def fraud_alerts():
    conn = psycopg2.connect(DB_URL)
    cur = conn.cursor()
    cur.execute("""
        SELECT code, reason, ts FROM affiliate_fraud_alerts
        WHERE ts > NOW() - INTERVAL '7 days' ORDER BY ts DESC
    """)
    results = [{"code": row[0], "reason": row[1], "ts": row[2].isoformat()} for row in cur.fetchall()]
    cur.close()
    conn.close()
    return jsonify(results)