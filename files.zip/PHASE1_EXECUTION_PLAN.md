# Phase 1: Refactor for Censorship Avoidance

_Context: Iranian market, censorship avoidance essential. Replace all "VPN" references with "PrivateWS", upgrade UI to RTL with Vazir font, obfuscate sensitive API endpoints, and localize all UI to Persian._

---

## 1. Rename All 'VPN' References to 'PrivateWS'

**a. Rename Components and Files**
- Rename: `components/VPNCard.jsx` → `components/AccessCard.jsx`
- Rename: `components/VPNList.jsx` → `components/AccessList.jsx` (if present)
- Update all imports, exports, and usages across project.

**b. Update Component Content**

_Example:_
```diff name=components/AccessCard.jsx
- export default function VPNCard({ vpnInfo }) {
-   return <div>{vpnInfo.name}</div>;
- }
+ export default function AccessCard({ wsInfo }) {
+   return <div>{wsInfo.name}</div>;
+ }
```

---

## 2. Obfuscate Sensitive API Endpoints

**a. Rename API Route**
- Move: `pages/api/vpn/index.js` → `pages/api/conn/index.js`

**b. Update Handler Names and Comments**

_Example:_
```diff name=pages/api/conn/index.js
- // ...vpn logic
+ // ...private workspace logic
```

**c. Update All API Calls in Frontend**
- Find and replace all `fetch("/api/vpn")` → `fetch("/api/conn")`

---

## 3. RTL & Persian Font Support

**a. Install Vazir Font**
```bash
npm install vazir-font
```

**b. Update `_app.js` for Global RTL & Font**
```diff name=pages/_app.js
+ import 'vazir-font/dist/font-face.css';
  import '../styles/globals.css';

- function MyApp({ Component, pageProps }) {
-   return <Component {...pageProps} />;
- }
+ function MyApp({ Component, pageProps }) {
+   return (
+     <div dir="rtl" style={{ fontFamily: 'Vazir, sans-serif' }}>
+       <Component {...pageProps} />
+     </div>
+   );
+ }
```

**c. Refactor CSS for RTL**

_Example:_
```diff name=styles/Card.module.css
- .card {
-   margin-left: 16px;
- }
+ .card {
+   margin-inline-start: 16px;
+ }
```

---

## 4. Generate Persian-Equivalent UI Strings

**a. Create Localization File**

```json name=locales/fa-IR.json
{
  "welcome": "به ورک‌اسپیس خصوصی خوش آمدید",
  "connect": "اتصال",
  "disconnect": "قطع اتصال",
  "settings": "تنظیمات",
  "status": "وضعیت",
  "active": "فعال",
  "inactive": "غیرفعال",
  "error": "خطا",
  "loading": "در حال بارگذاری...",
  "accessCardTitle": "دسترسی خصوصی",
  "apiError": "مشکلی پیش آمده است. لطفاً دوباره تلاش کنید."
}
```

**b. Refactor Components to Use Localized Strings**

_Example:_
```diff name=components/AccessCard.jsx
- export default function AccessCard({ wsInfo }) {
-   return <div>{wsInfo.name}</div>;
- }
+ import fa from '../locales/fa-IR.json';
+ export default function AccessCard({ wsInfo }) {
+   return (
+     <div>
+       <h2>{fa.accessCardTitle}</h2>
+       <span>{wsInfo.name}</span>
+     </div>
+   );
+ }
```

---

## 5. Summary of Key File Changes

| Old Name                    | New Name                 | Notes                                 |
|-----------------------------|--------------------------|---------------------------------------|
| components/VPNCard.jsx      | components/AccessCard.jsx| Rename all VPN → PrivateWS/Access     |
| pages/api/vpn/index.js      | pages/api/conn/index.js  | Obfuscate endpoint                    |
| fetch("/api/vpn")           | fetch("/api/conn")       | Update all front-end references       |
| styles/*.css                | styles/*.css             | Convert LTR to RTL                    |
| locales/fa-IR.json          | locales/fa-IR.json       | Persian translations                  |
| pages/_app.js               | pages/_app.js            | Vazir font & RTL layout               |

---

## 6. Test & PR

- [ ] Test layout in RTL and Persian.
- [ ] Ensure all API endpoints and UI texts are updated.
- [ ] Prepare PR:  
  ```
  ## [Security] Obfuscation Update
  - Renamed all VPN references to PrivateWS/Access
  - Added RTL support and Vazir font
  - Obfuscated API endpoints (`/api/vpn` → `/api/conn`)
  - Added Persian (fa-IR) localization file
  ```

---

_Need Phase 2 (payment gateway) prompt and code? Just ask!_