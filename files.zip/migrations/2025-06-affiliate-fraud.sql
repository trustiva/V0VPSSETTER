CREATE TABLE IF NOT EXISTS affiliate_fraud_alerts (
    id serial PRIMARY KEY,
    affiliate_id int,
    reason text,
    n_clicks int,
    ts timestamptz DEFAULT now()
);

ALTER TABLE users ADD COLUMN IF NOT EXISTS is_frozen boolean DEFAULT FALSE;