-- Add referrer, country, user_agent, ts columns if missing
ALTER TABLE referral_clicks ADD COLUMN IF NOT EXISTS referrer text;
ALTER TABLE referral_clicks ADD COLUMN IF NOT EXISTS country text;
ALTER TABLE referral_clicks ADD COLUMN IF NOT EXISTS user_agent text;
ALTER TABLE referral_clicks ADD COLUMN IF NOT EXISTS ts timestamptz DEFAULT now();

ALTER TABLE referral_conversions ADD COLUMN IF NOT EXISTS country text;
ALTER TABLE referral_conversions ADD COLUMN IF NOT EXISTS user_agent text;
ALTER TABLE referral_conversions ADD COLUMN IF NOT EXISTS ts timestamptz DEFAULT now();

-- Log VPN provision errors for system health
CREATE TABLE IF NOT EXISTS vpn_provision_errors (
  id serial PRIMARY KEY,
  ts timestamptz DEFAULT now(),
  error_msg text
);

-- Log payouts for system health
CREATE TABLE IF NOT EXISTS payouts (
  id serial PRIMARY KEY,
  user_id int,
  tron_address text,
  amount numeric,
  ts timestamptz DEFAULT now()
);