-- Store fraud alerts for dashboard/audit
CREATE TABLE IF NOT EXISTS affiliate_fraud_alerts (
    id serial PRIMARY KEY,
    code text,
    reason text,
    ts timestamptz DEFAULT now()
);

-- Add 'frozen' state to users
ALTER TABLE users ADD COLUMN IF NOT EXISTS frozen boolean DEFAULT FALSE;