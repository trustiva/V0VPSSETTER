import '../styles/globals.css';
import 'vazir-font/dist/font-face.css';

function MyApp({ Component, pageProps }) {
  return (
    <div dir="rtl" style={{ fontFamily: 'Vazir, sans-serif' }}>
      <Component {...pageProps} />
    </div>
  );
}

export default MyApp;