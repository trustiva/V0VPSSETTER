import { useState } from "react";
import { Line } from "react-chartjs-2";
import Chart from "chart.js/auto";
import fa from "../locales/fa-IR.json";
import "vazir-font/dist/font-face.css";

const mockUser = {
  name: "کاربر نمونه",
  phone: "09123456789",
  status: "فعال",
  expire: "۱۴۰۴-۰۴-۱۰",
  services: [
    { id: 1, name: "PrivateWS آلمان", status: "فعال", expires: "۱۴۰۴-۰۴-۱۰" }
  ]
};

const mockAnalytics = {
  labels: ["فروردین", "اردیبهشت", "خرداد", "تیر"],
  data: [15, 22, 18, 9] // GB traffic per month
};

export default function Dashboard() {
  const [dark, setDark] = useState(false);

  const chartData = {
    labels: mockAnalytics.labels,
    datasets: [
      {
        label: "حجم مصرفی (GB)",
        data: mockAnalytics.data,
        fill: false,
        borderColor: "#4F8A8B",
        backgroundColor: "#4F8A8B"
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: { display: true, labels: { font: { family: "Vazir, sans-serif" } } }
    },
    scales: {
      x: { ticks: { font: { family: "Vazir, sans-serif" } } },
      y: { ticks: { font: { family: "Vazir, sans-serif" } } }
    }
  };

  return (
    <div dir="rtl" style={{
      background: dark ? "#222" : "#fafafa",
      color: dark ? "#fff" : "#222",
      minHeight: "100vh",
      fontFamily: "Vazir, sans-serif",
      padding: 32
    }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <h1>داشبورد کاربری</h1>
        <button onClick={() => setDark(d => !d)} style={{
          background: "none", border: "1px solid #aaa", borderRadius: 8, padding: "4px 16px", color: dark ? "#fff" : "#222"
        }}>
          {dark ? "🌙 حالت روز" : "🌑 حالت شب"}
        </button>
      </div>
      <section style={{
        background: dark ? "#333" : "#fff",
        borderRadius: 12,
        padding: 24,
        margin: "24px 0",
        boxShadow: "0 2px 16px #0001"
      }}>
        <h2>اطلاعات حساب</h2>
        <div style={{ display: "flex", gap: 48, flexWrap: "wrap" }}>
          <div>نام: <b>{mockUser.name}</b></div>
          <div>شماره: <b>{mockUser.phone}</b></div>
          <div>وضعیت: <b>{mockUser.status}</b></div>
          <div>تمدید تا: <b>{mockUser.expire}</b></div>
        </div>
      </section>
      <section style={{
        background: dark ? "#333" : "#fff",
        borderRadius: 12,
        padding: 24,
        margin: "24px 0",
        boxShadow: "0 2px 16px #0001"
      }}>
        <h2>سرویس‌های فعال</h2>
        <table style={{ width: "100%", textAlign: "right", marginTop: 12 }}>
          <thead>
            <tr>
              <th>نام</th>
              <th>وضعیت</th>
              <th>انقضا</th>
            </tr>
          </thead>
          <tbody>
            {mockUser.services.map(s => (
              <tr key={s.id}>
                <td>{s.name}</td>
                <td>{s.status}</td>
                <td>{s.expires}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <button style={{
          marginTop: 20,
          background: "#4F8A8B",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "8px 24px"
        }}>
          تمدید یا خرید سرویس جدید
        </button>
      </section>
      <section style={{
        background: dark ? "#333" : "#fff",
        borderRadius: 12,
        padding: 24,
        margin: "24px 0",
        boxShadow: "0 2px 16px #0001"
      }}>
        <h2>تحلیل ترافیک ماهانه</h2>
        <Line data={chartData} options={chartOptions} height={100} />
      </section>
    </div>
  );
}