/**
 * MVP: Mock Shaparak callback verification endpoint.
 * TODO: Replace with actual DB verification and Shaparak API when available.
 */

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  // MVP: Simulate verification, log to console
  // TODO: Replace with actual DB call and Shaparak verification
  const { phone, amount, ref } = req.body || {};
  console.log("[MVP MOCK] Payment verified for", phone, amount, ref);

  // MVP: Simulate Telegram notification
  // TODO: Integrate Telegram bot/webhook here
  // await sendTelegramNotification(...);

  return res.status(200).json({ status: "verified", ref });
}