import { generateUSDTAddress } from "../../../lib/crypto";

/**
 * MVP: Mock endpoint to generate a USDT address for payment.
 * TODO: Replace with DB or wallet integration.
 */
export default function handler(req, res) {
  const { phone } = req.query;
  const address = generateUSDTAddress(phone || "");
  res.status(200).json({ address });
}