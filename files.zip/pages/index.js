import AccessList from "../components/AccessList";

export default function Home() {
  return <AccessList />;
}