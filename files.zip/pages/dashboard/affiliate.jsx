import { useEffect, useState } from "react";

export default function AffiliateDashboard() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    fetch("/api/affiliate/stats")
      .then(res => res.json())
      .then(setStats);
  }, []);

  if (!stats) return <div>Loading...</div>;

  return (
    <div dir="rtl" style={{ fontFamily: "Vazir, sans-serif", padding: 24 }}>
      <h1>داشبورد همکاری در فروش</h1>
      <p>لینک دعوت شما: <b>{stats.referral_link}</b></p>
      <div style={{
        display: "flex", gap: 32, margin: "24px 0"
      }}>
        <div>کلیک‌ها: <b>{stats.clicks}</b></div>
        <div>تبدیل‌ها: <b>{stats.conversions}</b></div>
        <div>کمیسیون کل: <b>{stats.earned} USDT</b></div>
      </div>
      <h2>توضیحات</h2>
      <ul>
        <li>درآمد شما به صورت هفتگی به کیف پول TRC20 واریز خواهد شد.</li>
        <li>برای اطلاع از وضعیت پرداخت و زیرمجموعه‌ها، همین صفحه را بررسی کنید.</li>
      </ul>
    </div>
  );
}