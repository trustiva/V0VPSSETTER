import { useEffect, useState } from "react";

export default function AffiliateAnalytics() {
  const [stats, setStats] = useState<any>(null);
  useEffect(() => {
    fetch("/api/affiliate-analytics?userId=me").then((r) => r.json()).then(setStats);
  }, []);
  if (!stats) return <div>در حال بارگذاری...</div>;
  return (
    <div dir="rtl" style={{ fontFamily: "Vazir, sans-serif", padding: 24 }}>
      <h1>آنالیتیکس پیشرفته همکاری در فروش</h1>
      <div style={{ margin: "16px 0" }}>
        <b>کلیک کل:</b> {stats.total_clicks} &nbsp;
        <b>تبدیل کل:</b> {stats.total_conversions} &nbsp;
        <b>درآمد:</b> {stats.total_earned} USDT &nbsp;
        <b>نرخ تبدیل:</b> {stats.conversion_rate}%
      </div>
      <h2>کشورهای برتر (کلیک)</h2>
      <ul>{Object.entries(stats.clicks_by_country).map(([c, v]) => <li key={c}>{c}: {v}</li>)}</ul>
      <h2>دستگاه‌ها و سیستم عامل‌ها (کلیک)</h2>
      <ul>{Object.entries(stats.clicks_by_device).map(([d, v]) => <li key={d}>{d}: {v}</li>)}</ul>
      <ul>{Object.entries(stats.clicks_by_os).map(([d, v]) => <li key={d}>{d}: {v}</li>)}</ul>
      <h2>کشورهای برتر (تبدیل)</h2>
      <ul>{Object.entries(stats.conversions_by_country).map(([c, v]) => <li key={c}>{c}: {v}</li>)}</ul>
      <h2>رفررهای برتر</h2>
      <ul>{stats.top_referrers.map((r: any) => <li key={r.referrer}>{r.referrer}: {r.count}</li>)}</ul>
      <h2>نمودار زمانی (کلیک/تبدیل)</h2>
      <pre>{JSON.stringify(stats.time_series, null, 2)}</pre>
      <pre>{JSON.stringify(stats.conv_time_series, null, 2)}</pre>
    </div>
  );
}