import { useEffect, useState } from "react";

export default function SystemHealth() {
  const [data, setData] = useState<any>(null);
  useEffect(() => {
    fetch("/api/systemHealth").then((r) => r.json()).then(setData);
  }, []);
  if (!data) return <div>در حال بارگذاری...</div>;
  return (
    <div style={{ fontFamily: "Vazir, sans-serif", padding: 24 }}>
      <h1>سلامت سیستم</h1>
      <div>
        <b>دیتابیس:</b> {data.db ? "✅" : "❌"}
        <b style={{ marginLeft: 24 }}>دامنه:</b> {data.domain ? "✅" : "❌"}
        <b style={{ marginLeft: 24 }}>تاریخ:</b> {data.ts}
      </div>
      <h2>آخرین پرداخت‌های همکاری در فروش</h2>
      <table>
        <thead><tr><th>کاربر</th><th>آدرس ترون</th><th>مبلغ</th><th>زمان</th></tr></thead>
        <tbody>
          {data.last_payouts.map((p: any) =>
            <tr key={p.ts + p.user_id}>
              <td>{p.user_id}</td>
              <td>{p.tron_address}</td>
              <td>{p.amount} USDT</td>
              <td>{p.ts}</td>
            </tr>
          )}
        </tbody>
      </table>
      <h2>آخرین خطاهای پروویژن VPN</h2>
      <ul>
        {data.vpn_errors.map((e: any) =>
          <li key={e.ts}>{e.ts}: {e.error_msg}</li>
        )}
      </ul>
    </div>
  );
}