## [Security] Obfuscation Update

- Renamed all VPN references to PrivateWS/Access
- Added RTL support and Vazir font
- Obfuscated API endpoints (`/api/vpn` → `/api/conn`)
- Added Persian (fa-IR) localization file