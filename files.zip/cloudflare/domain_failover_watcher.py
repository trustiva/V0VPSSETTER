import os
import time
import logging
from web3 import Web3
import requests

# --- Configuration ---
ETH_RPC_URL = os.getenv("ETH_RPC_URL", "https://mainnet.infura.io/v3/YOUR_INFURA_KEY")
CONTRACT_ADDRESS = os.getenv("DOMAIN_FAILOVER_CONTRACT", "0xYourContractAddress")
CONTRACT_ABI = [
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "internalType": "uint256", "name": "id", "type": "uint256"},
            {"indexed": True, "internalType": "address", "name": "requester", "type": "address"},
            {"indexed": False, "internalType": "uint256", "name": "amount", "type": "uint256"},
            {"indexed": False, "internalType": "uint256", "name": "timestamp", "type": "uint256"},
            {"indexed": False, "internalType": "string", "name": "requestedDomain", "type": "string"}
        ],
        "name": "DomainRequest",
        "type": "event"
    }
]
CLOUDFLARE_API_TOKEN = os.getenv("CLOUDFLARE_API_TOKEN")
CLOUDFLARE_ZONE_ID = os.getenv("CLOUDFLARE_ZONE_ID")
DNS_RECORD_TYPE = "A"
DNS_RECORD_TTL = 60  # seconds

LOG_PATH = os.getenv("DOMAIN_FAILOVER_LOG", "domain_failover_watcher.log")
logging.basicConfig(filename=LOG_PATH, level=logging.INFO, format="%(asctime)s %(message)s")

def update_dns(domain: str, ip: str = "1.2.3.4"):
    """Update or create an A record for the requested domain on Cloudflare."""
    endpoint = f"https://api.cloudflare.com/client/v4/zones/{CLOUDFLARE_ZONE_ID}/dns_records"
    headers = {
        "Authorization": f"Bearer {CLOUDFLARE_API_TOKEN}",
        "Content-Type": "application/json"
    }
    # Check if record exists
    params = {"type": DNS_RECORD_TYPE, "name": domain}
    resp = requests.get(endpoint, headers=headers, params=params)
    result = resp.json()
    if result.get("result"):
        # Update existing record
        record_id = result["result"][0]["id"]
        r = requests.put(
            f"{endpoint}/{record_id}",
            headers=headers,
            json={
                "type": DNS_RECORD_TYPE,
                "name": domain,
                "content": ip,
                "ttl": DNS_RECORD_TTL,
                "proxied": True
            }
        )
        logging.info(f"Updated DNS for {domain}: {r.status_code} {r.text}")
    else:
        # Create new record
        r = requests.post(
            endpoint,
            headers=headers,
            json={
                "type": DNS_RECORD_TYPE,
                "name": domain,
                "content": ip,
                "ttl": DNS_RECORD_TTL,
                "proxied": True
            }
        )
        logging.info(f"Created DNS for {domain}: {r.status_code} {r.text}")

def watch_events(last_block_file="last_block.txt", poll_interval=30):
    w3 = Web3(Web3.HTTPProvider(ETH_RPC_URL))
    contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=CONTRACT_ABI)
    try:
        with open(last_block_file, "r") as f:
            last_block = int(f.read().strip())
    except Exception:
        last_block = w3.eth.block_number - 10

    logging.info(f"Starting event watcher from block {last_block}")

    while True:
        latest_block = w3.eth.block_number
        if latest_block > last_block:
            events = contract.events.DomainRequest().get_logs(fromBlock=last_block+1, toBlock=latest_block)
            for ev in events:
                domain = ev["args"]["requestedDomain"]
                requester = ev["args"]["requester"]
                amount = Web3.fromWei(ev["args"]["amount"], "ether")
                logging.info(f"Domain request: {domain} by {requester} ({amount} ETH)")
                # Here you might want to generate a new IP or select from a pool
                update_dns(domain, ip="1.2.3.4")
            with open(last_block_file, "w") as f:
                f.write(str(latest_block))
            last_block = latest_block
        time.sleep(poll_interval)

if __name__ == "__main__":
    watch_events()