export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const target = url.searchParams.get("url");
    if (!target) {
      return new Response("Missing target url", { status: 400 });
    }
    const res = await fetch(target, request);
    // Optionally, strip headers/cookies for privacy:
    const filtered = new Headers(res.headers);
    filtered.delete("set-cookie");
    return new Response(res.body, {
      status: res.status,
      headers: filtered
    });
  }
};