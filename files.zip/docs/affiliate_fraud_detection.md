# Affiliate Fraud Detection System

## Features
- Uses anomaly detection (Isolation Forest) on affiliate click traffic to flag suspicious patterns (bots, same IPs, high anomalies).
- Auto-freezes affiliate accounts with >70% anomalous activity.
- Sends real-time Telegram alerts to admins.
- Logs all fraud alerts in `affiliate_fraud_alerts` table.
- Provides a dashboard for review.

## How it Works
1. Analyze last 14 days of clicks per affiliate.
2. Transform clicks to numerical features (IP, UA, country, timestamp).
3. Use Isolation Forest to detect outliers.
4. Freeze accounts with high anomaly ratio or obvious cheating (all clicks from same IP).
5. Log and notify for admin review.

## Integration
- Cron job runs `analytics/fraud_detector.py` daily.
- Dashboard UI at `/dashboard/fraud_alerts.jsx` shows all recent alerts.