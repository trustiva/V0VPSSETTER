# Guerrilla Update System

- Encrypts update payloads.
- Pins to IPFS (peer-to-peer distribution).
- Signs with blockchain key (verifiable authenticity).
- Broadcasts via Telegram channel (out-of-band notification).
- Verifiers (users or infra) check signature on-chain before applying update.