# AI Compliance & OPSEC Assistant

- Uses LLM to automatically generate:
  - Legal risk tables for IR/CN/RU (per stack element)
  - Plausible deniability strategies (network, code, infra)
  - Clean documentation for auditors or third parties

## Usage
- Run `scripts/ai_opsec_assistant.py` after stack or jurisdiction changes.
- Integrate outputs into compliance docs and onboarding.