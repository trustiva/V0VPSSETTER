# Self-Healing Architecture

## Features
- **Terraform**: Rapid deployment of 100+ Oracle Free Tier nodes in parallel.
- **Automatic DNS failover**: Script to update main domain DNS to new IPs during attack/block.
- **DDoS Protection**: AWS Shield integration for critical endpoints.

## Usage
- Run Terraform to provision Oracle fleet:  
  `cd infra/terraform && terraform init && terraform apply`
- Use rotate_dns.py to update DNS records to new IPs.
- Use AWS Shield for additional DDoS protection.

## Integration
- Wire these scripts to your block-detection/monitoring system for automatic escalation.
- Notify affiliates/admins on scaling/failover events.