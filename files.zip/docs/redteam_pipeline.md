# Adversarial Simulation System (Red Team/CI)

## Overview
This system simulates access to your platform from censorship-heavy countries (Iran, China, Russia), checks all main and fallback endpoints (e.g., .com, .onion, IPFS), and produces a compliance/hardening report.

## Key Features
- Automated weekly run (or on-demand via GitHub Actions).
- Uses Tor exit nodes to simulate country-specific access.
- Detects if endpoints are blocked, and tests fallback (IPFS/Tor).
- Alerts admin and logs results for compliance/hardening.
- CVSS-style block summary for risk assessment.

## Usage
- Set your main domain and fallback endpoints in `scripts/redteam/adversarial_simulation.sh`.
- Customize alerting as needed (Telegram/email/slack).
- Artifacts are uploaded in CI for audit and review.

## Integration
- Plug into hardening/monitoring dashboards.
- Schedule more frequently or extend to more countries as desired.