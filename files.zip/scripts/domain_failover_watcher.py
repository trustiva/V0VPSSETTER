import os
import time
import logging
import requests
from web3 import Web3

# --- CONFIGURATION ---
ETH_NODE_URL = os.getenv("ETH_NODE_URL", "https://mainnet.infura.io/v3/YOUR-PROJECT-ID")
CONTRACT_ADDRESS = os.getenv("DOMAIN_FAILOVER_CONTRACT", "0xYourContractAddress")
CONTRACT_ABI_PATH = os.getenv("CONTRACT_ABI_PATH", "contracts/DomainFailover.abi.json")  # Save ABI JSON here
CLOUDFLARE_API_TOKEN = os.getenv("CLOUDFLARE_API_TOKEN")
CLOUDFLARE_ZONE_ID = os.getenv("CLOUDFLARE_ZONE_ID")
DNS_RECORD_TYPE = os.getenv("DNS_RECORD_TYPE", "A")  # or "CNAME"
DNS_RECORD_NAME = os.getenv("DNS_RECORD_NAME", "failover.yourdomain.com")
NEW_DOMAIN_TARGET = os.getenv("NEW_DOMAIN_TARGET", "1.2.3.4")  # Could be set dynamically

LOG_PATH = os.getenv("DOMAIN_FAILOVER_LOG", "domain_failover_watcher.log")
logging.basicConfig(filename=LOG_PATH, level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# --- Load Contract ABI ---
import json
with open(CONTRACT_ABI_PATH, "r") as f:
    CONTRACT_ABI = json.load(f)

# --- Web3 Setup ---
w3 = Web3(Web3.HTTPProvider(ETH_NODE_URL))
contract = w3.eth.contract(address=Web3.to_checksum_address(CONTRACT_ADDRESS), abi=CONTRACT_ABI)

# --- Helper: Get last processed event block ---
STATE_PATH = ".last_domainfailover_block"
def get_last_block():
    try:
        with
