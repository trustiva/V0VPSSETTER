import openai
import os

PROMPT = """
Act as my red-team advisor. For my current stack:
1. List all legal risks in Iran/China/Russia
2. Suggest plausible deniability measures
3. Generate clean documentation templates
Output in Markdown tables with risk scores.
Stack: Next.js, Oracle, Cloudflare, Ethereum, Telegram, IPFS, Tor, affiliate payments.
"""

def get_opsec_analysis():
    openai.api_key = os.environ.get("OPENAI_API_KEY")
    resp = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": PROMPT}]
    )
    return resp.choices[0].message.content

if __name__ == "__main__":
    print(get_opsec_analysis())