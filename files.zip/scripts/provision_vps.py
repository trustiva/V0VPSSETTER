#!/usr/bin/env python3
"""
MVP: DigitalOcean VPS Provisioner for censorship avoidance.
Features:
- Creates droplets in optimized regions (Germany/Singapore)
- Installs WireGuard and Shadowsocks
- Generates QR config
- Handles IP block errors
- Triggers scaling if CPU >70%
- Notifies via Telegram (uses send_telegram.sh)
Replace 'YOUR_DIGITALOCEAN_API_TOKEN' and Telegram logic before production.
"""

import os
import requests
import subprocess
from time import sleep

DO_API = os.getenv("DO_API_TOKEN", "YOUR_DIGITALOCEAN_API_TOKEN")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
REGIONS = ["fra1", "sgp1"]  # Germany, Singapore

HEADERS = {
    "Authorization": f"Bearer {DO_API}",
    "Content-Type": "application/json"
}

def notify_telegram(message):
    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        subprocess.run([
            "./scripts/send_telegram.sh",
            TELEGRAM_BOT_TOKEN,
            TELEGRAM_CHAT_ID,
            message
        ])
    else:
        print("[Telegram Disabled] " + message)

def create_droplet(name, region):
    data = {
        "name": name,
        "region": region,
        "size": "s-1vcpu-1gb",
        "image": "ubuntu-22-04-x64",
        "ssh_keys": [],  # TODO: Add your SSH key IDs
        "backups": False,
        "ipv6": True,
        "user_data": "#cloud-config\nruncmd:\n  - apt update && apt install -y wireguard shadowsocks-libev qrencode\n"
    }
    resp = requests.post("https://api.digitalocean.com/v2/droplets", headers=HEADERS, json=data)
    if resp.status_code != 202:
        notify_telegram(f"❌ Droplet creation failed: {resp.text}")
        return None
    droplet = resp.json()["droplet"]
    notify_telegram(f"✅ Droplet '{name}' created in {region}. Waiting for setup...")
    return droplet["id"]

def get_droplet_ip(droplet_id):
    for _ in range(15):
        resp = requests.get(f"https://api.digitalocean.com/v2/droplets/{droplet_id}", headers=HEADERS)
        info = resp.json()["droplet"]
        if info["networks"]["v4"]:
            ip = info["networks"]["v4"][0]["ip_address"]
            return ip
        sleep(10)
    return None

def provision_vps():
    for region in REGIONS:
        name = f"privatews-{region}"
        droplet_id = create_droplet(name, region)
        if not droplet_id:
            continue
        ip = get_droplet_ip(droplet_id)
        if not ip:
            notify_telegram(f"❌ No IP for droplet {name}, possible block. Deleting droplet.")
            requests.delete(f"https://api.digitalocean.com/v2/droplets/{droplet_id}", headers=HEADERS)
            continue
        # TODO: SSH to setup WireGuard/Shadowsocks, generate QR, send via Telegram
        notify_telegram(f"🌐 VPS ready: {ip}\n(Setup instructions will be sent here)")
    # TODO: Check load and auto-scale if >70%

if __name__ == "__main__":
    provision_vps()