import os
import requests

def send_file(token, chat_id, file_path, caption):
    with open(file_path, "rb") as f:
        url = f"https://api.telegram.org/bot{token}/sendDocument"
        files = {"document": f}
        data = {"chat_id": chat_id, "caption": caption}
        resp = requests.post(url, files=files, data=data)
        print("File sent:", resp.status_code, resp.text)

def send_text(token, chat_id, message):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = {"chat_id": chat_id, "text": message}
    resp = requests.post(url, data=data)
    print("Text sent:", resp.status_code, resp.text)

if __name__ == "__main__":
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
    wg_path = os.getenv("WG_CONFIG_PATH", "wireguard.conf")
    ss_path = os.getenv("SS_CONFIG_PATH", "shadowsocks.json")
    ss_qr = os.getenv("SS_QR", "ss://...")  # Optionally pass QR code string

    send_file(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, wg_path, "WireGuard کانفیگ شما")
    send_file(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, ss_path, "Shadowsocks کانفیگ شما")
    if ss_qr:
        send_text(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, f"Shadowsocks QR:\n{ss_qr}")