#!/bin/bash
# Deploy site to 100 CDN subdomains

SITE_BUILD_DIR="out"
CDN_SUBDOMAIN_PREFIX="cdn"
DOMAIN="stealthnet.ir"
CDN_COUNT=100

# Example: S3/R2/Azure CLI deploy (replace with your provider's CLI)
for i in $(seq 1 $CDN_COUNT); do
  SUBDOMAIN="${CDN_SUBDOMAIN_PREFIX}-${i}.${DOMAIN}"
  echo "Deploying to $SUBDOMAIN..."
  # Example using AWS S3:
  # aws s3 sync "$SITE_BUILD_DIR" "s3://$SUBDOMAIN/"
  # or Azure/Cloudflare R2/etc.
done

echo "Updating DNS (Cloudflare API)..."
for i in $(seq 1 $CDN_COUNT); do
  SUBDOMAIN="${CDN_SUBDOMAIN_PREFIX}-${i}.${DOMAIN}"
  # Use your DNS provider's API to add/update A/CNAME record for $SUBDOMAIN
  # Example:
  # curl -X POST "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/dns_records" \
  #  -H "Authorization: Bearer $CF_API_TOKEN" \
  #  -d "{\"type\":\"CNAME\",\"name\":\"$SUBDOMAIN\",\"content\":\"your.cdn.endpoint.com\",\"ttl\":120,\"proxied\":true}"
done

echo "CDN deployment and DNS update complete."