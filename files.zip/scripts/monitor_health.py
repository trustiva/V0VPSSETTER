#!/usr/bin/env python3
import os
import subprocess
import psutil
import time

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

def notify_telegram(msg):
    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        subprocess.run([
            "./scripts/send_telegram.sh",
            TELEGRAM_BOT_TOKEN,
            TELEGRAM_CHAT_ID,
            msg
        ])
    else:
        print(msg)

def main():
    while True:
        cpu = psutil.cpu_percent()
        mem = psutil.virtual_memory().percent
        if cpu > 85 or mem > 90:
            notify_telegram(f"⚠️ VPS Overload: CPU {cpu}%, MEM {mem}%")
        time.sleep(60)

if __name__ == "__main__":
    main()