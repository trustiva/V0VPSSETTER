import os
import requests

def get_onion_address(hidden_service_dir="/var/lib/tor/hidden_service"):
    hostname_path = os.path.join(hidden_service_dir, "hostname")
    if os.path.isfile(hostname_path):
        with open(hostname_path, "r") as f:
            return f.read().strip()
    return None

def send_telegram_message(token, chat_id, message):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = {"chat_id": chat_id, "text": message}
    resp = requests.post(url, data=data)
    if resp.status_code == 200:
        print("Notification sent.")
    else:
        print("Failed to send notification:", resp.text)

if __name__ == "__main__":
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
    onion = get_onion_address()
    if onion:
        msg = f"🧅 Tor Hidden Service is live: {onion}\nAccess your service in Iran-blocked situations.\n\nHow to use: https://tbng.info/tor"
        send_telegram_message(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, msg)
    else:
        print("No .onion address found. Is Tor running and configured?")