import requests
import subprocess
import os
import time

PROXY = os.getenv("IRAN_PROXY", "http://iranproxy:port")
DOMAIN = os.getenv("MONITOR_DOMAIN", "yourdomain.com")
TOR_DEPLOY_SCRIPT = os.getenv("TOR_DEPLOY_SCRIPT", "deploy/deploy_tor_hidden_service.sh")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

def is_blocked():
    try:
        r = requests.get(f"https://{DOMAIN}", proxies={"http": PROXY, "https": PROXY}, timeout=10)
        return "Blocked" in r.text or r.status_code in (403, 451)
    except Exception:
        return True

def rotate_dns():
    print("Rotating DNS record (placeholder).")
    # requests.post(DNS_PROVIDER_API, json={...})

def notify(msg):
    if TELEGRAM_TOKEN and TELEGRAM_CHAT_ID:
        requests.post(f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
                      data={"chat_id": TELEGRAM_CHAT_ID, "text": msg})

def redeploy_tor():
    print("Redeploying Tor hidden service...")
    subprocess.call(["sudo", "bash", TOR_DEPLOY_SCRIPT])
    # Notify users with new .onion address
    subprocess.call(["python3", "scripts/notify_tor_onion.py"])

def main():
    if is_blocked():
        notify(f"🚨 Domain {DOMAIN} appears blocked in Iran! Rotating DNS and redeploying Tor hidden service.")
        rotate_dns()
        redeploy_tor()
    else:
        print("Domain is accessible.")

if __name__ == "__main__":
    while True:
        main()
        time.sleep(300)