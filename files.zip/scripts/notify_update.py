import telegram

bot = telegram.Bot(token="YOUR_TELEGRAM_BOT_TOKEN")
bot.send_message(
    chat_id="@yourchannel",
    text="🚨 New update available!\nCheck IPFS QmYourHash\nSignature: 0xYourSig"
)