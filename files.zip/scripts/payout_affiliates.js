// Requires: npm install tronweb pg axios dotenv
require('dotenv').config();
const TronWeb = require('tronweb');
const { Pool } = require('pg');
const axios = require('axios');

const pool = new Pool(); // Configure with .env

const tronWeb = new TronWeb({
  fullHost: 'https://api.trongrid.io',
  privateKey: process.env.TRON_PRIVATE_KEY,
});

// USDT contract on Tron mainnet
const USDT_CONTRACT = 'TXLAQ63Xg1NAzckPwKHvzw7CSEmLMEqcdj';
const PAYOUT_THRESHOLD = 10; // Minimum $ for payout

async function getAffiliatesToPay() {
  const res = await pool.query(`
    SELECT id, telegram_id, tron_address, balance
    FROM users
    WHERE balance >= $1 AND tron_address IS NOT NULL
  `, [PAYOUT_THRESHOLD]);
  return res.rows;
}

async function sendUSDT(to, amount) {
  const contract = await tronWeb.contract().at(USDT_CONTRACT);
  // USDT has 6 decimals
  const tx = await contract.transfer(to, amount * 1e6).send();
  return tx;
}

async function resetBalance(userId) {
  await pool.query("UPDATE users SET balance = 0 WHERE id = $1", [userId]);
}

async function notifyTelegram(telegramId, message) {
  if (!telegramId) return;
  const url = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`;
  await axios.post(url, { chat_id: telegramId, text: message });
}

(async () => {
  const affiliates = await getAffiliatesToPay();
  for (const aff of affiliates) {
    try {
      const tx = await sendUSDT(aff.tron_address, aff.balance);
      await notifyTelegram(aff.telegram_id, `🎉 کمیسیون شما (${aff.balance} USDT) پرداخت شد!\nTX: https://tronscan.org/#/transaction/${tx}`);
      await resetBalance(aff.id);
      console.log(`Paid ${aff.balance} USDT to ${aff.tron_address} (user ${aff.id})`);
    } catch (err) {
      console.error(`Failed to pay user ${aff.id}:`, err);
    }
  }
  process.exit();
})();