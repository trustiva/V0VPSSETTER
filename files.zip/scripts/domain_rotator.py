import subprocess

def regenerate_wireguard():
    # Replace with actual calls to your VPN automation
    subprocess.call(["python3", "provisioner/main.py"])
    # Optionally, send new config via Telegram

if __name__ == "__main__":
    regenerate_wireguard()