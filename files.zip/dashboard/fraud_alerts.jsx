import { useEffect, useState } from "react";

export default function FraudAlerts() {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    fetch("/api/fraud-alerts").then(r => r.json()).then(setAlerts);
  }, []);

  return (
    <div style={{fontFamily:"Vazir, sans-serif", padding:24}}>
      <h1>اخطارهای تقلب همکاری در فروش</h1>
      <table>
        <thead>
          <tr>
            <th>آیدی کاربر</th>
            <th>دلیل</th>
            <th>تعداد کلیک</th>
            <th>زمان</th>
          </tr>
        </thead>
        <tbody>
          {alerts.map(a => (
            <tr key={a.id}>
              <td>{a.affiliate_id}</td>
              <td>{a.reason}</td>
              <td>{a.n_clicks}</td>
              <td>{a.ts}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}