import os
from provisioner.vpn_config import generate_wireguard_config, generate_shadowsocks_config

def send_vpn_configs_telegram(wg_path, ss_path, ss_qr):
    import subprocess
    os.environ["WG_CONFIG_PATH"] = wg_path
    os.environ["SS_CONFIG_PATH"] = ss_path
    os.environ["SS_QR"] = ss_qr
    subprocess.call(["python3", "scripts/send_vpn_config_telegram.py"])

# ...in your provisioning success block...
if ip:
    print(f"Success! VPS at {ip} via {provider_name}")
    wg_config = generate_wireguard_config(ip, pubkey="SERVER_PUBKEY", preshared_key="PRESHAREDKEY", client_privkey="CLIENT_PRIVKEY")
    ss_config, ss_qr = generate_shadowsocks_config(ip, password="verysecret")
    wg_path = f"wireguard_{provider_name.lower()}_{ip}.conf"
    ss_path = f"shadowsocks_{provider_name.lower()}_{ip}.json"
    with open(wg_path, "w") as f:
        f.write(wg_config)
    with open(ss_path, "w") as f:
        import json; json.dump(ss_config, f, ensure_ascii=False, indent=2)
    print("WireGuard config saved:", wg_path)
    print("Shadowsocks config saved:", ss_path)
    print("Shadowsocks QR:", ss_qr)
    send_vpn_configs_telegram(wg_path, ss_path, ss_qr)
else:
    print("Provisioning failed with all providers.")