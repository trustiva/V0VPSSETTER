import os
import time
import logging
from datetime import datetime, timedelta
from typing import List, Dict

# Example VPS provider API stubs (replace with real SDKs or HTTP calls)
def list_servers() -> List[Dict]:
    """
    Returns a list of all active servers with their creation timestamps and IDs.
    Replace this with real provider API integration.
    """
    return [
        {"id": "hetzner-123", "provider": "Hetzner", "created_at": "2025-06-23T01:10:00Z"},
        {"id": "linode-456", "provider": "Linode", "created_at": "2025-06-24T01:30:00Z"},
        # ... more servers
    ]

def destroy_server(server_id: str, provider: str):
    """
    Destroys the server with the given ID on the specified provider.
    Replace with real API call.
    """
    logging.info(f"Destroyed server {server_id} on {provider}")

NUKE_THRESHOLD_HOURS = int(os.getenv("NUKE_THRESHOLD_HOURS", "48"))
LOG_PATH = os.getenv("NUKE_LOG_PATH", "nuke_and_rebuild.log")

logging.basicConfig(filename=LOG_PATH, level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")

def parse_iso8601(ts: str) -> datetime:
    # Assumes ts is in UTC and ISO8601 ("YYYY-MM-DDTHH:MM:SSZ")
    return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ")

def main():
    servers = list_servers()
    now = datetime.utcnow()
    nuke_count = 0

    for srv in servers:
        created = parse_iso8601(srv["created_at"])
        age = now - created
        if age > timedelta(hours=NUKE_THRESHOLD_HOURS):
            destroy_server(srv["id"], srv["provider"])
            logging.info(f"Server {srv['id']} ({srv['provider']}) nuked after {age}")
            nuke_count += 1

    logging.info(f"Nuke & Rebuild run complete. {nuke_count} servers destroyed.")

if __name__ == "__main__":
    main()