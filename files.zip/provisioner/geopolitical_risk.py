import requests
import re
import time
from datetime import datetime
from collections import defaultdict

# --- CONFIGURATION ---
TELEGRAM_CHANNELS = [
    # Public channels posting about censorship or internet disruptions
    "IranInternetWatch", "GreatFirewallReport"
]
TWITTER_HANDLES = [
    "netblocks", "OONIorg"
]
KEYWORDS = [
    "block", "ban", "restriction", "cloud", "provider", "Hetzner", "Linode", "Oracle", "AWS", "region", "datacenter"
]
REGION_PATTERNS = {
    "Hetzner": re.compile(r"(Hetzner|Germany|Finland|Nuremberg|Helsinki)", re.I),
    "Linode": re.compile(r"(Linode|Tokyo|Singapore|London|Frankfurt|Newark|Toronto)", re.I),
    "Oracle": re.compile(r"(Oracle|Ashburn|Phoenix|Frankfurt|London|Zurich|Mumbai|Seoul)", re.I),
    # Add more as needed
}
TELEGRAM_BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
TELEGRAM_API_URL = "https://api.telegram.org"

def fetch_telegram_alerts(channel):
    # Scrape last 20 messages from the public Telegram channel using a bot API or scraper
    # For demo, use a placeholder as Telegram bot API can't fetch public channel history
    # You may use Telethon or other libraries for actual implementation
    return []

def fetch_twitter_alerts(handle):
    # Placeholder: Use Twitter API or scraping. Here, just a stub.
    return []

def risk_score_from_text(text):
    text = text.lower()
    score = 0
    for k in KEYWORDS:
        if k in text:
            score += 2
    return score

def classify_risks():
    region_risks = defaultdict(list)
    # Telegram
    for channel in TELEGRAM_CHANNELS:
        alerts = fetch_telegram_alerts(channel)
        for alert in alerts:
            for provider, pat in REGION_PATTERNS.items():
                if pat.search(alert["text"]):
                    risk = risk_score_from_text(alert["text"])
                    region_risks[provider].append((risk, alert["text"], alert["date"]))
    # Twitter
    for handle in TWITTER_HANDLES:
        tweets = fetch_twitter_alerts(handle)
        for tweet in tweets:
            for provider, pat in REGION_PATTERNS.items():
                if pat.search(tweet["text"]):
                    risk = risk_score_from_text(tweet["text"])
                    region_risks[provider].append((risk, tweet["text"], tweet["date"]))
    # Aggregate
    provider_risk = {}
    for provider, events in region_risks.items():
        total = sum(x[0] for x in events)
        provider_risk[provider] = {
            "score": total,
            "events": events,
        }
    return provider_risk

if __name__ == "__main__":
    risks = classify_risks()
    print("Geopolitical risk scores:")
    for provider, data in risks.items():
        print(f"{provider}: {data['score']} (events: {len(data['events'])})")
        for ev in data["events"]:
            print(f"- [{ev[2]}] {ev[1][:80]}")