import base64

def generate_wireguard_config(server_ip, pubkey, preshared_key, client_privkey, client_ip="10.66.66.2/32", server_port=51820):
    return f"""[Interface]
PrivateKey = {client_privkey}
Address = {client_ip}
DNS = 1.1.1.1

[Peer]
PublicKey = {pubkey}
PresharedKey = {preshared_key}
Endpoint = {server_ip}:{server_port}
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
"""

def generate_shadowsocks_config(server_ip, password, method="chacha20-ietf-poly1305", server_port=8388):
    config = {
        "server": server_ip,
        "server_port": server_port,
        "password": password,
        "method": method,
        "plugin": "",
        "plugin_opts": ""
    }
    # Shadowsocks QR code format: ss://BASE64(method:password@host:port)
    userinfo = f"{method}:{password}@{server_ip}:{server_port}"
    qr = "ss://" + base64.urlsafe_b64encode(userinfo.encode()).decode().rstrip("=")
    return config, qr