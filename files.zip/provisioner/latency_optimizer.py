import subprocess
import threading
import time

# Example region endpoints by provider
REGION_ENDPOINTS = {
    "Hetzner": {
        "Germany": "speed.hetzner.de",
        "Finland": "speed.hel.hetzner.com",
    },
    "Linode": {
        "Tokyo": "speedtest.tokyo2.linode.com",
        "Frankfurt": "speedtest.frankfurt.linode.com",
    },
    "Oracle": {
        "Frankfurt": "fra.oc-test.oraclevcn.com",
        "Ashburn": "ash.oc-test.oraclevcn.com",
    }
}

def ping_host(host, count=3, timeout=1):
    cmd = ["ping", "-c", str(count), "-W", str(timeout), host]
    try:
        output = subprocess.check_output(cmd, stderr=subprocess.STDOUT).decode()
        lines = [l for l in output.splitlines() if "time=" in l]
        times = [float(line.split("time=")[1].split()[0]) for line in lines]
        avg = sum(times) / len(times) if times else None
        return avg
    except Exception:
        return None

def measure_latencies():
    results = {}
    threads = []

    def worker(provider, region, host):
        latency = ping_host(host)
        results[(provider, region)] = latency

    for provider, regions in REGION_ENDPOINTS.items():
        for region, host in regions.items():
            t = threading.Thread(target=worker, args=(provider, region, host))
            t.start()
            threads.append(t)

    for t in threads:
        t.join()

    # Sort by lowest latency
    sorted_results = sorted(results.items(), key=lambda kv: (kv[1] if kv[1] is not None else 9999))
    return sorted_results

if __name__ == "__main__":
    print("Measuring region latencies...")
    results = measure_latencies()
    print("Best regions by latency:")
    for ((provider, region), latency) in results:
        print(f"{provider} - {region}: {latency if latency is not None else 'N/A'} ms")
    if results:
        best = next(((p, r, l) for ((p, r), l) in results if l is not None), None)
        if best:
            print(f"\nRecommended: {best[0]} {best[1]} ({best[2]:.2f} ms)")
        else:
            print("\nNo available regions found.")