import boto3
import os
import requests

ORACLE_AUTOSCALE_WEBHOOK = os.environ["ORACLE_AUTOSCALE_WEBHOOK"]
ADMIN_EMAIL = os.environ["ADMIN_EMAIL"]

def lambda_handler(event, context):
    # Assume event is a block/attack notification
    # 1. Trigger Oracle autoscale webhook
    requests.post(ORACLE_AUTOSCALE_WEBHOOK, json={"action": "scale", "count": 50})

    # 2. Notify admin (SES example)
    ses = boto3.client("ses")
    ses.send_email(
        Source=ADMIN_EMAIL,
        Destination={"ToAddresses":[ADMIN_EMAIL]},
        Message={
            "Subject":{"Data":"Block Escalation Triggered"},
            "Body":{"Text":{"Data":"50+ Oracle nodes are being provisioned for failover."}}
        }
    )
    return {"status": "ok"}