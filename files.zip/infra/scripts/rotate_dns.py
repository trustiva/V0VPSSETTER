import requests
import os

CLOUDFLARE_API_TOKEN = os.getenv("CF_API_TOKEN")
CLOUDFLARE_ZONE_ID = os.getenv("CF_ZONE_ID")
DOMAIN = "yourdomain.com"
NEW_IPS = ["1.2.3.4", "5.6.7.8"]  # Update with provisioned Oracle IPs

def update_dns(ip):
    url = f"https://api.cloudflare.com/client/v4/zones/{CLOUDFLARE_ZONE_ID}/dns_records"
    headers = {"Authorization": f"Bearer {CLOUDFLARE_API_TOKEN}", "Content-Type": "application/json"}
    # You may wish to delete old records before creating new ones
    r = requests.post(url, headers=headers, json={
        "type": "A",
        "name": DOMAIN,
        "content": ip,
        "ttl": 60,
        "proxied": True
    })
    print(f"Set {DOMAIN} to {ip}: {r.status_code}")

for ip in NEW_IPS:
    update_dns(ip)