# Project Features

## 1. Multi-Cloud Automated Server Provisioning
- Provisions VPS servers with fallback across Hetzner, Linode, Oracle Cloud.
- Automatically skips blocked or failed providers.
- Unified API for server creation, deletion, and IP monitoring.

## 2. Unified VPN Configuration Generation
- Generates WireGuard and Shadowsocks configs for provisioned servers.
- Supports automated key/password generation.
- Outputs configs in user-friendly formats (file, QR, etc).

## 3. Smart Traffic Routing Middleware (Next.js)
- Detects blocked users by IP/country/geolocation.
- Redirects blocked users to:
  - IPFS-hosted static content.
  - Cloudflare Worker proxy.
  - Tor hidden service (.onion) for unblockable access.
- Dynamically rotates domains and access points.

## 4. IPFS and Tor Hidden Service Deployment
- Automated scripts to deploy static site to IPFS.
- Automated script to deploy Tor hidden service for emergency access.
- Outputs and notifies on new .onion addresses.

## 5. Block Detection & Auto-DNS Rotator
- Periodically checks main domain accessibility from block-prone regions (e.g. Iran, China).
- If blocked, rotates DNS records and triggers alternative access deployment.
- Telegram notifications for admins/users on block detection.

## 6. Telegram Integration
- Sends VPN configs (files and QR) to users via Telegram bot.
- Notifies users/admins on new Tor addresses, block events, and payouts.

## 7. Affiliate/Referral System
- Referral links with click/conversion tracking.
- Dashboard for affiliates with real-time stats.
- Automated commission calculation and balance tracking.

## 8. Automated Affiliate Payouts
- Weekly USDT (TRC20) payouts to affiliates.
- TronWeb integration for blockchain payments.
- Telegram notification of payouts.

## 9. Advanced Analytics & Monitoring
- Affiliate analytics: clicks, conversions, conversion rates, device/OS/country breakdown, time series.
- System health dashboard: DB, domain uptime, recent payouts, VPN provision errors.
- Tables for payouts, errors, referral activity.
- Real-time and historical tracking for business/technical metrics.

## 10. System Automation & Reliability
- All key scripts/services (block monitor, payouts, Tor/IPFS deploy) run on cron/systemd timers.
- .env-driven configuration for secure and flexible deployment.

---

**Optional/Planned Features:**
- Affiliate payout smart contract.
- Deep anomaly/fraud detection for affiliates.
- UI charts and visualizations for analytics.
- USDT wallet management and payout history for users.
- More provider integrations (e.g. AWS, DigitalOcean, Vultr).
- Multi-language support for user dashboard and notifications.