module.exports = {
  i18n: {
    locales: ['en', 'fa'],
    defaultLocale: 'en',
    localeDetection: true,
  },
};