import { useState } from "react";
import { ethers } from "ethers";
import { useTranslation } from "next-i18next";
import DomainFailoverABI from "../abis/DomainFailover.json";

const CONTRACT_ADDRESS = "0xYourContractAddress";

export default function DomainWalletRequest() {
  const [domain, setDomain] = useState("");
  const [status, setStatus] = useState("");
  const { t } = useTranslation("common");

  async function requestDomain() {
    if (!window.ethereum) return setStatus(t('install_metamask'));
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(CONTRACT_ADDRESS, DomainFailoverABI, signer);

    try {
      const tx = await contract.requestNewDomain(domain, {
        value: ethers.utils.parseEther("0.01"),
      });
      setStatus(t('transaction_sent') + ": " + tx.hash);
      await tx.wait();
      setStatus(t('domain_request_sent'));
    } catch (e) {
      setStatus(t('error') + ": " + e.message);
    }
  }

  return (
    <div>
      <h3>{t('request_domain')}</h3>
      <input
        placeholder={t('domain_placeholder')}
        value={domain}
        onChange={e => setDomain(e.target.value)}
      />
      <button onClick={requestDomain}>{t('request_button')}</button>
      <div>{status}</div>
    </div>
  );
}