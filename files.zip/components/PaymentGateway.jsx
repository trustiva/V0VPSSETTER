import { useState } from "react";

const paymentMethods = [
  { key: "shaparak", label: "شاپرک (شبیه‌ساز)" },
  { key: "usdt", label: "USDT (TRC20)" }
];

// MVP: All payment data is mocked. Actual DB integration should replace fetch endpoints.

export default function PaymentGateway() {
  const [method, setMethod] = useState(paymentMethods[0].key);
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // Validate Iranian phone
  const isValidPhone = (p) => /^(\+98|0)?9\d{9}$/.test(p);

  // Handle payment submission
  const handlePayment = async (e) => {
    e.preventDefault();
    setMessage("");
    setAddress("");
    if (!isValidPhone(phone)) {
      setMessage("شماره موبایل معتبر وارد کنید");
      return;
    }
    setLoading(true);

    if (method === "shaparak") {
      // MVP: Simulate Shaparak payment
      setTimeout(() => {
        setLoading(false);
        setMessage("درگاه شاپرک (شبیه‌ساز): پرداخت انجام شد. منتظر تایید بمانید...");
      }, 1500);
    } else if (method === "usdt") {
      // MVP: Fetch mock USDT address
      const res = await fetch("/api/payment/usdt?phone=" + encodeURIComponent(phone));
      const data = await res.json();
      setAddress(data.address);
      setLoading(false);
      setMessage("لطفاً مبلغ را به آدرس زیر ارسال کنید و منتظر تایید بمانید.");
    }
  };

  return (
    <div className="payment-gateway">
      <h2>درگاه پرداخت</h2>
      <div>
        {paymentMethods.map((m) => (
          <label key={m.key} style={{ marginInlineEnd: 16 }}>
            <input
              type="radio"
              value={m.key}
              checked={method === m.key}
              onChange={() => setMethod(m.key)}
            />
            {m.label}
          </label>
        ))}
      </div>
      <form onSubmit={handlePayment} style={{ marginTop: 20 }}>
        <input
          type="tel"
          placeholder="شماره موبایل (مثال: 09123456789)"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          style={{ direction: "ltr", marginInlineEnd: 10 }}
        />
        <button type="submit" disabled={loading}>
          پرداخت
        </button>
      </form>
      {loading && <div>در حال ارسال...</div>}
      {message && <div style={{ marginTop: 12 }}>{message}</div>}
      {method === "usdt" && address && (
        <div style={{ marginTop: 12, wordBreak: "break-all" }}>
          <b>آدرس کیف پول:</b>
          <div>{address}</div>
        </div>
      )}
    </div>
  );
}