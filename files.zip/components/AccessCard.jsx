import fa from '../locales/fa-IR.json';

export default function AccessCard({ wsInfo }) {
  return (
    <div className="card">
      <h2>{fa.accessCardTitle}</h2>
      <span>{wsInfo.name}</span>
      <button>{fa.connect}</button>
    </div>
  );
}