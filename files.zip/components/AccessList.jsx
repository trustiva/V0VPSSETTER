import { useEffect, useState } from "react";
import AccessCard from "./AccessCard";
import fa from '../locales/fa-IR.json';

export default function AccessList() {
  const [workspaces, setWorkspaces] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/conn")
      .then((res) => res.json())
      .then((data) => {
        setWorkspaces([data]);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <div>{fa.loading}</div>;

  return (
    <div>
      <h1>{fa.welcome}</h1>
      {workspaces.map((ws, idx) => (
        <AccessCard key={idx} wsInfo={ws} />
      ))}
    </div>
  );
}