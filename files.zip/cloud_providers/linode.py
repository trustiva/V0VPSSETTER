import os
import requests
import time

class LinodeProvider:
    def __init__(self, api_token=None):
        self.api_token = api_token or os.getenv("LINODE_API_TOKEN")
        self.base_url = "https://api.linode.com/v4"
        self.headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json"
        }

    def list_regions(self):
        resp = requests.get(f"{self.base_url}/regions", headers=self.headers)
        resp.raise_for_status()
        return resp.json()["data"]

    def best_region(self, preferred=["ap-south", "ap-northeast", "ap-southeast"]):
        # Optionally ping/test, here just pick first preferred in available
        regions = self.list_regions()
        id_to_region = {r['id']: r for r in regions}
        for region in preferred:
            if region in id_to_region:
                return id_to_region[region]
        return regions[0]

    def create_instance(self, label="privatews-asia", instance_type="g6-nanode-1", image="linode/ubuntu22.04", ssh_keys=None):
        region = self.best_region()
        payload = {
            "region": region["id"],
            "type": instance_type,
            "image": image,
            "label": label
        }
        if ssh_keys:
            payload["authorized_keys"] = ssh_keys
        resp = requests.post(f"{self.base_url}/linode/instances", headers=self.headers, json=payload)
        resp.raise_for_status()
        instance = resp.json()
        return instance

    def wait_for_ipv4(self, instance_id, timeout=180):
        for _ in range(timeout // 6):
            resp = requests.get(f"{self.base_url}/linode/instances/{instance_id}", headers=self.headers)
            resp.raise_for_status()
            instance = resp.json()
            ipv4 = instance.get("ipv4", [])
            if ipv4:
                return ipv4[0]
            time.sleep(6)
        return None

    def delete_instance(self, instance_id):
        resp = requests.delete(f"{self.base_url}/linode/instances/{instance_id}", headers=self.headers)
        return resp.status_code == 200

    def is_blocked(self, ip):
        # TODO: Implement real block-check logic (e.g., probe from Iran)
        return False

# Example Usage:
# linode = LinodeProvider(api_token="YOUR_TOKEN")
# instance = linode.create_instance()
# ip = linode.wait_for_ipv4(instance["id"])
# if linode.is_blocked(ip):
#     linode.delete_instance(instance["id"])