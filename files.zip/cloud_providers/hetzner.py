import os
import requests
import time

class HetznerProvider:
    def __init__(self, api_token=None):
        self.api_token = api_token or os.getenv("HETZNER_API_TOKEN")
        self.base_url = "https://api.hetzner.cloud/v1"
        self.headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json"
        }

    def list_locations(self):
        resp = requests.get(f"{self.base_url}/locations", headers=self.headers)
        resp.raise_for_status()
        return resp.json()["locations"]

    def best_location(self, preferred=["fsn1", "hel1", "nbg1"]):
        # Optionally ping/test, but here just pick first preferred
        locations = self.list_locations()
        code_to_loc = {loc['name']: loc for loc in locations}
        for region in preferred:
            if region in code_to_loc:
                return code_to_loc[region]
        return locations[0]

    def create_server(self, name="privatews-eu", server_type="cx11", image="ubuntu-22.04", ssh_keys=None):
        location = self.best_location()
        payload = {
            "name": name,
            "server_type": server_type,
            "image": image,
            "location": location["name"],
        }
        if ssh_keys:
            payload["ssh_keys"] = ssh_keys
        resp = requests.post(f"{self.base_url}/servers", headers=self.headers, json=payload)
        resp.raise_for_status()
        server = resp.json()["server"]
        return server

    def wait_for_ipv4(self, server_id, timeout=180):
        for _ in range(timeout // 6):
            resp = requests.get(f"{self.base_url}/servers/{server_id}", headers=self.headers)
            resp.raise_for_status()
            server = resp.json()["server"]
            for ip in server.get("public_net", {}).get("ipv4", {}).values():
                if isinstance(ip, str) and ip.count(".") == 3:
                    return ip
            time.sleep(6)
        return None

    def delete_server(self, server_id):
        resp = requests.delete(f"{self.base_url}/servers/{server_id}", headers=self.headers)
        return resp.status_code == 204

    def is_blocked(self, ip):
        # TODO: Implement real block-check logic (e.g., probe from Iran)
        return False

# Example Usage:
# hetzner = HetznerProvider(api_token="YOUR_TOKEN")
# server = hetzner.create_server()
# ip = hetzner.wait_for_ipv4(server["id"])
# if hetzner.is_blocked(ip):
#     hetzner.delete_server(server["id"])