import { NextResponse } from 'next/server';

export function middleware(request) {
  // Example: Get a block score from a custom header (set at edge or by a prior middleware)
  const blockScore = Number(request.headers.get('x-block-score') || 0);

  if (blockScore > 7) {
    // Pick a random stealth CDN subdomain for failover
    const cdnNum = Math.floor(Math.random() * 100) + 1;
    const url = new URL(request.url);
    url.hostname = `cdn-${cdnNum}.stealthnet.ir`;
    return NextResponse.rewrite(url.toString());
  }
  // Otherwise, proceed as normal
  return NextResponse.next();
}

// Optionally, configure matcher for routes you want to protect
export const config = {
  matcher: ["/((?!_next|api|static).*)"],
};