#!/bin/bash
# Requires: ipfs CLI, running daemon, and ipfs add

BUILD_DIR=out  # or .next or your static export dir
IPFS_HASH=$(ipfs add -r -Q "$BUILD_DIR")
echo "IPFS Hash: $IPFS_HASH"
# Optionally update your middleware config automatically here