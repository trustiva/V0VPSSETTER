#!/bin/bash
# This script installs and configures a Tor hidden service for your web/vpn server

# --- CONFIGURATION ---
HIDDEN_SERVICE_DIR="/var/lib/tor/hidden_service"
ONION_PORT=80      # Port exposed on .onion (Tor side)
TARGET_PORT=8080   # Your real local web server/VPN port

# --- INSTALL TOR ---
sudo apt update
sudo apt install -y tor

# --- ENABLE HIDDEN SERVICE ---
sudo bash -c "cat >> /etc/tor/torrc" <<EOF

# Added by deploy_tor_hidden_service.sh
HiddenServiceDir $HIDDEN_SERVICE_DIR
HiddenServicePort $ONION_PORT 127.0.0.1:$TARGET_PORT
EOF

sudo systemctl restart tor

# --- OUTPUT .ONION ADDRESS ---
sleep 3
if [ -f "$HIDDEN_SERVICE_DIR/hostname" ]; then
    ONION_ADDR=$(sudo cat $HIDDEN_SERVICE_DIR/hostname)
    echo "Your Tor hidden service is live at: $ONION_ADDR"
else
    echo "Error: Could not find .onion address. Check Tor logs."
fi