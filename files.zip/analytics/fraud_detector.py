import os
import logging
import psycopg2
import numpy as np
from sklearn.ensemble import IsolationForest
from datetime import datetime, timedelta
import telegram

# --- CONFIG ---
DB_URL = os.getenv("DATABASE_URL")
TELEGRAM_TOKEN = os.getenv("FRAUD_ALERT_BOT_TOKEN")
ALERT_CHAT_ID = os.getenv("FRAUD_ALERT_CHAT_ID")

# Model params
IFOREST_CONTAM = 0.02  # ~2% expected outlier rate
MIN_CLICKS = 30        # Minimum data points to run model

logging.basicConfig(level=logging.INFO)

def fetch_affiliate_clicks(conn):
    """Fetch recent affiliate clicks for analysis."""
    # Sample features: timestamp, affiliate_id, ip, user_agent, referrer, country
    with conn.cursor() as cur:
        cur.execute("""
            SELECT affiliate_id, ip, EXTRACT(EPOCH FROM ts), user_agent, country
            FROM referral_clicks
            WHERE ts > NOW() - INTERVAL '14 days'
        """)
        rows = cur.fetchall()
    return rows

def feature_engineering(clicks):
    """Transform clicks into features for anomaly detection."""
    # Features: time, IP frequency, UA hash, country code
    from hashlib import sha1

    # Map IPs and UAs to integers, country to int
    ip2idx = {}
    ua2idx = {}
    ctry2idx = {}
    X = []
    for row in clicks:
        aff, ip, t, ua, ctry = row
        if ip not in ip2idx: ip2idx[ip] = len(ip2idx)
        if ua not in ua2idx: ua2idx[ua] = len(ua2idx)
        if ctry not in ctry2idx: ctry2idx[ctry] = len(ctry2idx)
        X.append([
            t,
            ip2idx[ip],
            ua2idx[ua],
            ctry2idx[ctry] if ctry else -1
        ])
    return np.array(X), [row[0] for row in clicks]

def run_anomaly_detection(X):
    """Fit Isolation Forest and return outlier indices."""
    if X.shape[0] < MIN_CLICKS:
        return []
    clf = IsolationForest(n_estimators=150, contamination=IFOREST_CONTAM, random_state=42)
    y_pred = clf.fit_predict(X)
    return np.where(y_pred == -1)[0]  # Outlier indices

def freeze_affiliate(conn, affiliate_id):
    with conn.cursor() as cur:
        cur.execute("UPDATE users SET is_frozen=TRUE WHERE id=%s", (affiliate_id,))
    conn.commit()

def send_fraud_alert(affiliate_id, reason, n_clicks):
    msg = f"🚨 Affiliate Fraud Detected!\nUser: {affiliate_id}\nReason: {reason}\nClicks: {n_clicks}"
    if TELEGRAM_TOKEN and ALERT_CHAT_ID:
        bot = telegram.Bot(token=TELEGRAM_TOKEN)
        bot.send_message(chat_id=ALERT_CHAT_ID, text=msg)
    logging.warning(msg)

def main():
    conn = psycopg2.connect(DB_URL)
    clicks = fetch_affiliate_clicks(conn)
    if not clicks:
        logging.info("No clicks found.")
        return

    # Group by affiliate
    from collections import defaultdict
    aff2rows = defaultdict(list)
    for row in clicks:
        aff2rows[row[0]].append(row)

    for aff_id, rows in aff2rows.items():
        X, _ = feature_engineering(rows)
        outliers = run_anomaly_detection(X)
        if len(outliers) > 0 and len(outliers)/len(rows) > 0.7:
            # High ratio: likely fraud
            freeze_affiliate(conn, aff_id)
            send_fraud_alert(aff_id, "High anomaly score (bot/cheat)", len(rows))
        # Additional rule: too many clicks from same IP or UA
        ips = [r[1] for r in rows]
        if len(rows) > 20 and len(set(ips)) == 1:
            freeze_affiliate(conn, aff_id)
            send_fraud_alert(aff_id, "All clicks from same IP", len(rows))
    conn.close()

if __name__ == "__main__":
    main()