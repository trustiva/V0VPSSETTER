import { Pool } from "pg";
import { NextApiRequest, NextApiResponse } from "next";

// Utility: Parse user agent for device/OS stats
function parseUserAgent(ua: string) {
  if (!ua) return { device: "Unknown", os: "Unknown" };
  const isMobile = /Android|iPhone|iPad|iPod/i.test(ua);
  const os = /Android/i.test(ua)
    ? "Android"
    : /iPhone|iPad|iPod/i.test(ua)
    ? "iOS"
    : /Windows/i.test(ua)
    ? "Windows"
    : /Mac OS X/i.test(ua)
    ? "MacOS"
    : /Linux/i.test(ua)
    ? "Linux"
    : "Other";
  return { device: isMobile ? "Mobile" : "Desktop", os };
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

/**
 * Returns advanced affiliate analytics for a user:
 * - Clicks by country
 * - Clicks by device/OS
 * - Conversion rates (total, by country, by device)
 * - Top referrers and top converting links
 * - Time series for clicks/conversions
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const userId = req.query.userId || req.body.userId;
  if (!userId) return res.status(400).json({ error: "userId required" });

  // 1. Clicks by country/device
  const clicks = await pool.query(
    `SELECT country, user_agent, ts FROM referral_clicks WHERE code = (SELECT code FROM users WHERE id=$1)`,
    [userId]
  );
  const countryStats: Record<string, number> = {};
  const deviceStats: Record<string, number> = {};
  const osStats: Record<string, number> = {};
  const timeSeries: Record<string, number> = {};

  clicks.rows.forEach((row) => {
    countryStats[row.country || "Unknown"] = (countryStats[row.country || "Unknown"] || 0) + 1;
    const { device, os } = parseUserAgent(row.user_agent);
    deviceStats[device] = (deviceStats[device] || 0) + 1;
    osStats[os] = (osStats[os] || 0) + 1;
    const day = row.ts.toISOString().slice(0, 10);
    timeSeries[day] = (timeSeries[day] || 0) + 1;
  });

  // 2. Conversions by country/device
  const conversions = await pool.query(
    `SELECT country, user_agent, ts, amount FROM referral_conversions WHERE code = (SELECT code FROM users WHERE id=$1)`,
    [userId]
  );
  const convCountryStats: Record<string, number> = {};
  const convDeviceStats: Record<string, number> = {};
  const convOsStats: Record<string, number> = {};
  const convTimeSeries: Record<string, number> = {};
  let totalEarned = 0;

  conversions.rows.forEach((row) => {
    convCountryStats[row.country || "Unknown"] = (convCountryStats[row.country || "Unknown"] || 0) + 1;
    const { device, os } = parseUserAgent(row.user_agent);
    convDeviceStats[device] = (convDeviceStats[device] || 0) + 1;
    convOsStats[os] = (convOsStats[os] || 0) + 1;
    const day = row.ts.toISOString().slice(0, 10);
    convTimeSeries[day] = (convTimeSeries[day] || 0) + 1;
    totalEarned += Number(row.amount || 0);
  });

  // 3. Conversion rate
  const conversionRate = clicks.rows.length
    ? ((conversions.rows.length / clicks.rows.length) * 100).toFixed(2)
    : "0.00";

  // 4. Top referrers (if you store referrer in clicks table)
  const topReferrers = await pool.query(
    `SELECT referrer, COUNT(*) AS count FROM referral_clicks WHERE code = (SELECT code FROM users WHERE id=$1) GROUP BY referrer ORDER BY count DESC LIMIT 5`,
    [userId]
  );

  res.json({
    total_clicks: clicks.rows.length,
    total_conversions: conversions.rows.length,
    total_earned: totalEarned,
    conversion_rate: conversionRate,
    clicks_by_country: countryStats,
    clicks_by_device: deviceStats,
    clicks_by_os: osStats,
    conversions_by_country: convCountryStats,
    conversions_by_device: convDeviceStats,
    conversions_by_os: convOsStats,
    time_series: timeSeries,
    conv_time_series: convTimeSeries,
    top_referrers: topReferrers.rows,
  });
}