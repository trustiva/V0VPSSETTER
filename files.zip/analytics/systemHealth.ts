import { Pool } from "pg";
import { NextApiRequest, NextApiResponse } from "next";

// Simple system health endpoint for dashboard/alerts
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export default async function handler(_req: NextApiRequest, res: NextApiResponse) {
  // 1. DB health
  try {
    await pool.query("SELECT 1");
  } catch (e) {
    return res.status(500).json({ ok: false, db: false });
  }
  // 2. Recent payouts
  const lastPayouts = await pool.query(
    "SELECT user_id, tron_address, amount, ts FROM payouts ORDER BY ts DESC LIMIT 10"
  );
  // 3. Recent VPN provision errors (if you log in a table)
  let vpnErrors: any[] = [];
  try {
    const errors = await pool.query(
      "SELECT ts, error_msg FROM vpn_provision_errors ORDER BY ts DESC LIMIT 10"
    );
    vpnErrors = errors.rows;
  } catch {}
  // 4. Uptime check (example: call your production domain)
  let domainOK = false;
  try {
    const resp = await fetch(process.env.MONITOR_DOMAIN || "https://yourdomain.com");
    domainOK = resp.status < 400;
  } catch {}
  res.json({
    ok: true,
    db: true,
    domain: domainOK,
    last_payouts: lastPayouts.rows,
    vpn_errors: vpnErrors,
    ts: new Date().toISOString(),
  });
}